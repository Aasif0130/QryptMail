import React from "react";
import { Outlet } from "react-router-dom";

const BlankLayout = () => (
  <>
    <Outlet />
  </>
);

export default BlankLayout;
